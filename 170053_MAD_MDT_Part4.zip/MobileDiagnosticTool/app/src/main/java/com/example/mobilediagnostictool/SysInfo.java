package com.example.mobilediagnostictool;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SysInfo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sys_info);
    }
}
