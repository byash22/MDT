package com.example.mobilediagnostictool;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class connectionsdiagnose extends AppCompatActivity {

    // This file tells that through which network we have connected like Wifi,Mobile Internet, No connection.
        //Views
        ImageView mconStatusIv;
        TextView mconStatusTv;
        Button mconStatusBtn;


        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            // Set the network_act.xml file
            setContentView(R.layout.activity_connectionsdiagnose);

            // Link views with XML

            mconStatusIv = findViewById(R.id.conStatusIv);
            mconStatusTv = findViewById(R.id.conStatusTv);
            mconStatusBtn = findViewById(R.id.conStatusBtn);

            // button click to check network status
            mconStatusBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    // function call to check network connection status

                    checkNetworkConnectionStatus ();

                }
            });

        }

        private void checkNetworkConnectionStatus() {
            boolean wifiConnected;
            boolean mobileConnected;
            ConnectivityManager connMgr = (ConnectivityManager)
                    getSystemService(Context.CONNECTIVITY_SERVICE);

            NetworkInfo activeInfo = connMgr.getActiveNetworkInfo();
            if (activeInfo !=null && activeInfo.isConnected()){ // connected with either mobile or wifi

                wifiConnected =activeInfo.getType() == ConnectivityManager.TYPE_WIFI;
                mobileConnected =activeInfo.getType() == ConnectivityManager.TYPE_MOBILE;

                if (wifiConnected){ // wifi connected
                    mconStatusIv.setImageResource(R.drawable.ic_action_wifi);
                    mconStatusTv.setText("Connected with Wifi");

                }
                else if (mobileConnected){ // mobile connected
                    mconStatusIv.setImageResource(R.drawable.ic_data);
                    mconStatusTv.setText("Connected with Mobile Data");
                }
            }
            else { // no internet Connection

                mconStatusIv.setImageResource(R.drawable.ic_action_no);
                mconStatusTv.setText("No Internet Connection");

            }
        }
    }

