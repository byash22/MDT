package com.example.mobilediagnostictool;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class sensorsdiagnose extends AppCompatActivity {

    SensorManager sem = null;
    TextView textView1 = null;
    TextView textgyro = null;
    TextView textrotation = null;
    TextView textgravity = null;
    TextView textproximity = null;
    TextView textorientation = null;
    TextView textmangetometer = null;
    Sensor listacc;
    Sensor gyroscope;
    Sensor rotation;
    Sensor gravity;
    Sensor proximity;
    Sensor orientation;
    Sensor magnetometer;

    private static final int SENSOR_DELAY = 500 * 1000; // 500ms
    private static final int FROM_RADS_TO_DEGS = -57;

    SensorEventListener accelerometerEvent = new SensorEventListener(){
        public void onAccuracyChanged(Sensor sensor, int accuracy) {}
        public void onSensorChanged(SensorEvent event) {
            float[] values = event.values;
            textView1.setText("x: "+values[0]+"\ny: "+values[1]+"\nz: "+values[2]);
        }
    };

    SensorEventListener gyroListener = new SensorEventListener() {
        public void onAccuracyChanged(Sensor sensor, int acc) { }
        public void onSensorChanged(SensorEvent event) {
            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];

            textgyro.setText("X : " + (int)x + " rad/s \n" + "Y : " + (int)y + " rad/s \n" + "Z : " + (int)z + " rad/s" );
        }
    };

    SensorEventListener magnetoListener = new SensorEventListener() {
        public void onAccuracyChanged(Sensor sensor, int acc) { }
        public void onSensorChanged(SensorEvent event) {
            float[] values = event.values;
            textmangetometer.setText("x: "+values[0]+"\ny: "+values[1]+"\nz: "+values[2]);
        }
    };

    SensorEventListener rotationListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            if (sensorEvent.sensor == rotation) {
                if (sensorEvent.values.length > 4) {
                    float[] truncatedRotationVector = new float[4];
                    System.arraycopy(sensorEvent.values, 0, truncatedRotationVector, 0, 4);
                    update(truncatedRotationVector);
                } else {
                    update(sensorEvent.values);
                }
            }
        }
        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {

        }
    };

    SensorEventListener gravityListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {

        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {

        }
    };

    SensorEventListener proximityListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            if (sensorEvent.sensor.getType() == Sensor.TYPE_PROXIMITY) {
                if (sensorEvent.values[0] == 0) {
                    textproximity.setText("Near");
                } else {
                    textproximity.setText("Away");
                }
            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {

        }
    };

    private void update(float[] vectors) {
        float[] rotationMatrix = new float[9];
        SensorManager.getRotationMatrixFromVector(rotationMatrix, vectors);
        int worldAxisX = SensorManager.AXIS_X;
        int worldAxisZ = SensorManager.AXIS_Z;
        float[] adjustedRotationMatrix = new float[9];
        SensorManager.remapCoordinateSystem(rotationMatrix, worldAxisX, worldAxisZ, adjustedRotationMatrix);
        float[] orientation = new float[3];
        SensorManager.getOrientation(adjustedRotationMatrix, orientation);
        float pitch = orientation[1] * FROM_RADS_TO_DEGS;
        float roll = orientation[2] * FROM_RADS_TO_DEGS;
        textrotation.setText("Pitch: "+pitch + "\nRoll: "+roll);
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /* Get a SensorManager instance */
        sem = (SensorManager)getSystemService(SENSOR_SERVICE);

        textView1 = (TextView)findViewById(R.id.textView2);
        textgyro = (TextView)findViewById(R.id.textView4);
        textrotation = (TextView) findViewById(R.id.textView6);
        textgravity = (TextView) findViewById(R.id.textView8);
        textproximity = (TextView)findViewById(R.id.textView10);
        textmangetometer = (TextView) findViewById(R.id.textView14);
        listacc = sem.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gyroscope = sem.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        rotation = sem.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        gravity = sem.getDefaultSensor(Sensor.TYPE_GRAVITY);
        proximity = sem.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        magnetometer = sem.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
    }

    protected void onResume() {
        super.onResume();
        sem.registerListener(gyroListener, (Sensor) gyroscope, SensorManager.SENSOR_DELAY_NORMAL);
        sem.registerListener(accelerometerEvent, (Sensor) listacc, SensorManager.SENSOR_DELAY_NORMAL);
        sem.registerListener(rotationListener, (Sensor) rotation, SensorManager.SENSOR_DELAY_NORMAL);
        sem.registerListener(proximityListener, (Sensor) proximity, SensorManager.SENSOR_DELAY_NORMAL );
        sem.registerListener(magnetoListener, (Sensor) proximity, SensorManager.SENSOR_DELAY_NORMAL );
    }

    @Override
    protected void onStop() {
        sem.unregisterListener(accelerometerEvent);
        sem.unregisterListener(gyroListener);
        sem.unregisterListener(rotationListener);
        sem.unregisterListener(proximityListener);
        sem.unregisterListener(magnetoListener);
        super.onStop();
    }
}
