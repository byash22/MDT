package com.example.mobilediagnostictool;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

// By Yash (170053)
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button mobinfo = (Button) findViewById(R.id.mobinfo);
        mobinfo.setOnClickListener(new View.OnClickListener() {
                                       @Override
                                       public void onClick(View view) {
                                           Intent myintent = new Intent(MainActivity.this, MobInfo.class);
                                           startActivity(myintent);
                                       }
                                   });

            Button sysdiag = (Button) findViewById(R.id.sysdiag);
         sysdiag.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent a = new Intent(MainActivity.this, Diagnosis.class);
                    startActivity(a);
                }

        });
    }
}
