package com.example.mobilediagnostictool;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.TargetApi;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.annotation.Target;

public class batterydiagnose extends AppCompatActivity {

    private TextView result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_batterydiagnose);
        result = (TextView) findViewById(R.id.result);
        loadbatteryinfo();
    }
    private void loadbatteryinfo(){
        IntentFilter intentfilter = new IntentFilter();
        intentfilter.addAction(Intent.ACTION_POWER_CONNECTED);
        intentfilter.addAction(Intent.ACTION_POWER_DISCONNECTED);
        intentfilter.addAction(Intent.ACTION_BATTERY_CHANGED);

       // registerReceiver(batteryinfo)

    }

    private void batteryData(Intent intent){
        boolean present = intent.getBooleanExtra(BatteryManager.EXTRA_PRESENT, false);
        if (present) {
            StringBuilder batteryinfo = new StringBuilder();
            int health = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, 0);
            batteryinfo.append("Health : " + health).append("\n\n");

            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);

            if (level != -1 && scale != -1) {
                int batterypct = (int) ((level / (float) scale) * 100f);
                batteryinfo.append("Battery Percentage : " + batterypct).append("\n\n");
            }

            int plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
            batteryinfo.append("Plugged : " + plugged).append("\n\n");

            int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            batteryinfo.append("Charging Status : " + status).append("\n\n");

            if (intent.getExtras() != null) {
                String tech = intent.getExtras().getString(BatteryManager.EXTRA_TECHNOLOGY);
                batteryinfo.append("Technology : " + tech).append("\n\n");
            }

            long capacity = getBatteryCapacity();
            batteryinfo.append("Capacity : " + capacity).append("\n\n");

            result.setText(batteryinfo.toString());
        }
        else {
            Toast.makeText(batterydiagnose.this, "No Battery Present", Toast.LENGTH_SHORT).show();
        }
    }
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private long getBatteryCapacity(){
        if(Build.VERSION.SDK_INT >- Build.VERSION_CODES.LOLLIPOP){
            BatteryManager BatteryMgr = (BatteryManager) getSystemService(Context.BATTERY_SERVICE);
            Long chargecounter = BatteryMgr.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);
            Long capacity = BatteryMgr.getLongProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);

            if (chargecounter != null && capacity != null) {
                long value = (long) (((float) chargecounter / (float) capacity) * 100f);
                return value;
            }
        }
        return 0;
    }
    private BroadcastReceiver batteryInfoReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            batteryData(intent);
        }
    };
}
