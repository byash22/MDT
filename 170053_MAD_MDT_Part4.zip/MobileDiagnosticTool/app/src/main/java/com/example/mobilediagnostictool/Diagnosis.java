package com.example.mobilediagnostictool;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.GridView;
// By Yash (170053)
public class Diagnosis extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CardView screen = (CardView) findViewById(R.id.screen);
        screen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myintent = new Intent(Diagnosis.this, screendiagnose.class);
                startActivity(myintent);
            }
        });

        CardView camera = (CardView) findViewById(R.id.camera);
        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a = new Intent(Diagnosis.this, cameradiagnose.class);
                startActivity(a);
            }
        });


        CardView sound = (CardView) findViewById(R.id.sound);
        sound.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent b = new Intent(Diagnosis.this, sounddiagnose.class);
                startActivity(b);
            }
        });



        CardView hardware = (CardView) findViewById(R.id.hardware);
        hardware.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent d = new Intent(Diagnosis.this, batterydiagnose.class);
                startActivity(d);
            }
        });


        CardView connections = (CardView) findViewById(R.id.connections);
        connections.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent s = new Intent(Diagnosis.this, connectionsdiagnose.class);
                startActivity(s);
            }
        });

        CardView sensor = (CardView) findViewById(R.id.sensor);
        sensor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent q = new Intent(Diagnosis.this, sensorsdiagnose.class);
                startActivity(q);
            }
        });


    }
}
