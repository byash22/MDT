package com.example.mobilediagnostictool;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MobInfo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mob_info);

        Button specs = (Button) findViewById(R.id.specs);
        specs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myintent = new Intent(MobInfo.this, DeviceSpec.class);
                startActivity(myintent);
            }
        });

        Button sysinfo = (Button) findViewById(R.id.sysinfo);
        sysinfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myintent = new Intent(MobInfo.this, SysInfo.class);
                startActivity(myintent);
            }
        });
    }
}
