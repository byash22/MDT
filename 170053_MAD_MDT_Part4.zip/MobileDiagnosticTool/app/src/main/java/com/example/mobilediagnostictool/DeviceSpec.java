package com.example.mobilediagnostictool;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import java.io.IOException;
import java.io.InputStream;

        public class DeviceSpec extends Fragment {

            ProcessBuilder processBuilder;
            String Holder = "";
            String[] DATA = {"/system/bin/cat", "/proc/cpuinfo"};
            InputStream inputStream;
            Process process ;
            byte[] byteArry ;
            String IMEI,IMSI;

            public static final int REQUEST_CODE_PHONE_STATE_READ = 100;
            private int checkedPermission = PackageManager.PERMISSION_DENIED;

            @Nullable
            @Override
            public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
                View rootView = inflater.inflate(R.layout.activity_device_spec, container, false);
                final TextView textView = rootView.findViewById(R.id.Specs);
                checkedPermission = ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_PHONE_STATE);
                if (Build.VERSION.SDK_INT >= 23 && checkedPermission != PackageManager.PERMISSION_GRANTED) {
                    requestPermission();
                } else
                    checkedPermission = PackageManager.PERMISSION_GRANTED;

                TelephonyManager manager = (TelephonyManager) getActivity().getSystemService(Context.TELEPHONY_SERVICE);
                IMEI = manager.getDeviceId();
                IMSI = manager.getSubscriberId();

                byteArry = new byte[1024];

                try{
                    processBuilder = new ProcessBuilder(DATA);
                    process = processBuilder.start();
                    inputStream = process.getInputStream();
                    while(inputStream.read(byteArry) != -1){
                        Holder = Holder + new String(byteArry);
                    }
                    inputStream.close();
                } catch(IOException ex){
                    ex.printStackTrace();
                }

                textView.setText(
                        "SERIAL: " + Build.SERIAL + "\n" +
                                "MODEL: " + Build.MODEL + "\n" +
                                "ID: " + Build.ID + "\n" +
                                "Manufacture: " + Build.MANUFACTURER + "\n" +
                                "Brand: " + Build.BRAND + "\n" +
                                "Type: " + Build.TYPE + "\n" +
                                "User: " + Build.USER + "\n" +
                                "BASE: " + Build.VERSION_CODES.BASE + "\n" +
                                "INCREMENTAL: " + Build.VERSION.INCREMENTAL + "\n" +
                                "SDK:  " + Build.VERSION.SDK + "\n" +
                                "BOARD: " + Build.BOARD + "\n" +
                                "BRAND: " + Build.BRAND + "\n" +
                                "HOST: " + Build.HOST + "\n" +
                                "FINGERPRINT: " + Build.FINGERPRINT + "\n" +
                                "Version Code: " + Build.VERSION.RELEASE + "\n" +
                                "IMEI: " + IMEI + "\n" +
                                "IMSI: " + IMSI  + "\n" +
                                Holder
                );
                return rootView;
            }
            @RequiresApi(api = Build.VERSION_CODES.M)
            private void requestPermission() {
                this.requestPermissions(new String[]{Manifest.permission.READ_PHONE_STATE},
                        REQUEST_CODE_PHONE_STATE_READ);
            }
            @Override
            public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

                switch (requestCode) {
                    case REQUEST_CODE_PHONE_STATE_READ:
                        if (grantResults.length > 0 && grantResults[0]== PackageManager.PERMISSION_GRANTED ) {
                            checkedPermission = PackageManager.PERMISSION_GRANTED;
                        }
                        break;

                }
            }
        }
